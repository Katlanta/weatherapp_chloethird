# week-1
Initial weather app for week 1