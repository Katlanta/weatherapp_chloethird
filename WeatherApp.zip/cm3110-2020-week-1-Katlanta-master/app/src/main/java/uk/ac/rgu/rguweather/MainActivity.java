package uk.ac.rgu.rguweather;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.Random;

/**
 * Implementation for the main activity
 */
public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    // member variable for the user provided location
    private String location;
    EditText editArea;
    TextView editOutput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // get the Get Forecast button
        Button btnGetForecast = findViewById(R.id.btnGetForecast);

        editArea = (EditText) findViewById(R.id.etLocationInput);
        editOutput = (TextView) findViewById(R.id.tvLocationDisplay);

        // set the click listener to the btnGetForecast Button
        btnGetForecast.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        // view is the View (Button, ExitText, TextView, etc) that was clicked
        RandomWeatherForecastGetter getter = new RandomWeatherForecastGetter(this);
        // if it was the btnGetForecast

        if (view.getId() == R.id.btnGetForecast) {
            String area = editArea.getText().toString();
            area = area.replaceAll("\\s", "");
            String weather = getter.getWeather();
            if (editArea.length() > 0) {
                editOutput.setText("The weather in : " + area + " is - " + weather);
                Toast.makeText(getApplicationContext(), "Location Received!", Toast.LENGTH_LONG).show();
            } else {
                editOutput.setText("Please Fill In The Field");
        }
    }
}
}